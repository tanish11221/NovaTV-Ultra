package com.novatv.ultra

import android.content.Intent
import android.os.Bundle
import android.content.pm.ResolveInfo
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF080B18)
private val Panel = Color(0xFF12182B)
private val Purple = Color(0xFF8B78FF)
private val Cyan = Color(0xFF50D8E8)
private val Muted = Color(0xFF9AA5C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

data class LaunchableApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable?)

@Composable
fun NovaApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("Home") }
    var showSettings by remember { mutableStateOf(false) }
    val apps = remember {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val leanback = Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.LEANBACK_LAUNCHER")
        val results = (pm.queryIntentActivities(launcher, 0) + pm.queryIntentActivities(leanback, 0))
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != context.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        results.map { LaunchableApp(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Purple, secondary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF111A36), Navy, Color(0xFF080B18)))
            )
        ) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Header(onSettings = { showSettings = !showSettings })
                if (showSettings) {
                    SettingsPanel(onBack = { showSettings = false })
                } else {
                    NavigationBar(selectedTab, onSelect = { selectedTab = it })
                    HeroBanner()
                    if (selectedTab == "Apps" || selectedTab == "Home") {
                        Text("YOUR APPS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        if (apps.isEmpty()) {
                            Text("No launchable apps found.", color = Muted)
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(apps, key = { it.packageName }) { app ->
                                    AppTile(app) {
                                        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
                                        if (launch != null) context.startActivity(launch)
                                    }
                                }
                            }
                        }
                    }
                    if (selectedTab == "Movies" || selectedTab == "Series") {
                        InfoCard(
                            title = "$selectedTab",
                            subtitle = "Add your own streaming apps to access your content here.",
                            icon = if (selectedTab == "Movies") Icons.Default.Movie else Icons.Default.Tv
                        )
                    }
                    if (selectedTab == "Home") {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                            QuickCard("Display", "Wallpaper & screen", Icons.Default.Tune, Modifier.weight(1f)) { showSettings = true }
                            QuickCard("System", "Device settings", Icons.Default.Settings, Modifier.weight(1f)) {
                                context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                            }
                        }
                    }
                    Text("NOVA TV ULTRA  •  MADE FOR THE BIG SCREEN", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
            }
        }
    }
}

@Composable
fun Header(onSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Purple, Cyan))), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = Navy)
            }
            Column {
                Text("NovaTV", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("ULTRA", fontSize = 9.sp, color = Cyan, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ANDROID TV", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White) }
        }
    }
}

@Composable
fun NavigationBar(selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Home", "Apps", "Movies", "Series").forEach { tab ->
            val active = selected == tab
            Surface(
                onClick = { onSelect(tab) },
                shape = RoundedCornerShape(50),
                color = if (active) Purple.copy(alpha = .22f) else Panel.copy(alpha = .75f),
                border = if (active) BorderStroke(1.dp, Purple) else null
            ) {
                Text(tab, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                    color = if (active) Color.White else Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun HeroBanner() {
    Box(
        Modifier.fillMaxWidth().heightIn(min = 150.dp).clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF342A72), Color(0xFF174C69), Color(0xFF171D39))))
            .padding(20.dp)
    ) {
        Column(Modifier.fillMaxWidth(.78f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("WELCOME TO", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Text("YOUR ENTERTAINMENT\nUNIVERSE", color = Color.White, fontSize = 25.sp, lineHeight = 29.sp, fontWeight = FontWeight.ExtraBold)
            Text("Everything you love, one screen away.", color = Color(0xFFD2D9EF), fontSize = 12.sp)
            Surface(color = Color.White.copy(alpha = .14f), shape = RoundedCornerShape(50)) {
                Text("EXPLORE APPS  →", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp))
            }
        }
        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Cyan.copy(alpha = .45f),
            modifier = Modifier.align(Alignment.CenterEnd).size(74.dp))
    }
}

@Composable
fun AppTile(app: LaunchableApp, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        Modifier.width(104.dp).animateContentSize().onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(18.dp))
            .background(if (focused) Color(0xFF29365B) else Panel)
            .borderIf(focused, Purple)
            .clickable(onClick = onClick).focusable().padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Icon(Icons.Default.Apps, contentDescription = app.label, tint = Cyan, modifier = Modifier.size(48.dp))
        Text(app.label, color = Color.White, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Modifier.borderIf(enabled: Boolean, color: Color): Modifier =
    if (enabled) this.then(Modifier.background(Color.Transparent).padding(1.dp)) else this

@Composable
fun QuickCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(18.dp), color = Panel) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, contentDescription = null, tint = Cyan)
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(subtitle, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun InfoCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(shape = RoundedCornerShape(20.dp), color = Panel, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(32.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SettingsPanel(onBack: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        listOf(
            "Display & Wallpaper" to Icons.Default.DisplaySettings,
            "Sound & Audio" to Icons.Default.VolumeUp,
            "Network & Internet" to Icons.Default.Wifi,
            "Apps Management" to Icons.Default.Apps,
            "Personalization" to Icons.Default.Palette,
            "Security & Privacy" to Icons.Default.Security,
            "System Information" to Icons.Default.Info
        ).forEach { (label, icon) ->
            Surface(shape = RoundedCornerShape(14.dp), color = Panel, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(icon, contentDescription = null, tint = Cyan)
                    Text(label, color = Color.White, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}
