# NovaTV Ultra — Android Launcher starter project

This is a starter Android Studio project written in Kotlin + Jetpack Compose.

## Target devices
- Android TV (including Android 13)
- Android phones (including Android 16)
- Minimum Android version: API 23

## Included in this starter
- Dark premium-style launcher home screen
- Home / Apps / Movies / Series navigation
- Installed app discovery (launcher activities)
- App launching
- Settings panel UI
- Android HOME intent filter (so Android can offer it as a Home app)
- Touch and basic D-pad focus support

## Important limitations
- This is a starter project, not a finished commercial launcher.
- Some TV manufacturers restrict replacing the system launcher.
- The settings rows are currently UI placeholders; they do not change protected system settings.
- App icons are represented by a generic icon in this first version.
- Weather, cloud sync, media catalogs, OTA updates, and custom wallpaper downloading are not implemented.
- 4K displays are supported through Android density scaling; actual output depends on the device and display.

## Build on a computer
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK under `app/build/outputs/apk/debug/app-debug.apk`.

## Build from a phone
Android Studio itself does not run natively on Android. Use a cloud development environment that supports Android SDK + Gradle builds, or a trusted remote computer. Do not install APKs from unknown build websites.

Package name: `com.novatv.ultra`
App name: `NovaTV Ultra`
